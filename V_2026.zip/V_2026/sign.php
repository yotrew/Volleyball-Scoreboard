<?
function sign()
{
	echo "<br>-----<br>\n";
	echo "程式開發者:<a href=https://github.com/yotrew>Yotrew Wing</a>, anran ";
	echo "@cs.ccu.edu.tw<br>\n";
	echo "-----20xx (cc)-----<br>\n";
}
?>
